<!DOCTYPE html>
<html lang="en">
<head>
    <title>Email</title>
</head>
<body>
    <p>{!! $body !!}</p>
</body>
</html>